<?php

/**
 * Created by IntelliJ IDEA.
 * User: Himanshu
 * Date: 1/7/2017
 * Time: 10:22 PM
 */
class AdminAppModel extends AppModel
{

}