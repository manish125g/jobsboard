<?php

/**
 * Created by IntelliJ IDEA.
 * User: Himanshu
 * Date: 1/15/2017
 * Time: 2:14 PM
 */
class Job extends AppModel
{
    public $name = 'Job';

}