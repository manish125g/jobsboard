<?php

/**
 * Created by PhpStorm.
 * User: Manish
 * Date: 21/07/2017
 * Time: 11:25 AM
 */
class Heading extends AppModel
{
    public $useTable = 'heading';
}