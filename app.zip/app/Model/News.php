<?php

/**
 * Created by IntelliJ IDEA.
 * User: Himanshu
 * Date: 1/15/2017
 * Time: 2:14 PM
 */
class News extends AppModel
{
    public $name = 'News';

    public $useTable = 'news';

}